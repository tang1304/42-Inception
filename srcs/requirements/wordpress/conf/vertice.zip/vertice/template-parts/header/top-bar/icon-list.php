<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<ul class="wp-block wp-block-kubio-iconlist  position-relative wp-block-kubio-iconlist__outer vertice-header__k__tZhDISQj5L-outer vertice-local-607-outer ul-list-icon list-type-horizontal-on-desktop list-type-horizontal-on-tablet list-type-horizontal-on-mobile" data-kubio="kubio/iconlist">
	<?php $component->printIcons(); ?>
</ul>

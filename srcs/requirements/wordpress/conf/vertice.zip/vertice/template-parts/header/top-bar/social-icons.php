<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<div class="wp-block wp-block-kubio-social-icons  position-relative wp-block-kubio-social-icons__outer vertice-header__k__xtchq9B1o-5-outer vertice-local-615-outer social-icons--container" data-kubio="kubio/social-icons">
	<?php $component->printIcons(); ?>
</div>

<div class="wp-block wp-block-kubio-navigation-top-bar  kubio-hide-on-mobile position-relative wp-block-kubio-navigation-top-bar__outer vertice-header__k__dukKAjLGgS-outer vertice-local-604-outer d-flex align-items-lg-center align-items-md-center align-items-center" data-kubio="kubio/navigation-top-bar">
	<div class="background-wrapper">
		<div class="background-layer background-layer-media-container-lg"></div>
		<div class="background-layer background-layer-media-container-md"></div>
		<div class="background-layer background-layer-media-container"></div>
	</div>
	<div class="position-relative wp-block-kubio-navigation-top-bar__inner vertice-header__k__dukKAjLGgS-inner vertice-local-604-inner h-section-grid-container h-section-boxed-container">
		<div class="wp-block wp-block-kubio-row  position-relative wp-block-kubio-row__container vertice-header__k__NJ1mZRrmEM-container vertice-local-605-container gutters-row-lg-0 gutters-row-v-lg-0 gutters-row-md-0 gutters-row-v-md-0 gutters-row-0 gutters-row-v-0" data-kubio="kubio/row">
			<div class="background-wrapper">
				<div class="background-layer background-layer-media-container-lg"></div>
				<div class="background-layer background-layer-media-container-md"></div>
				<div class="background-layer background-layer-media-container"></div>
			</div>
			<div class="position-relative wp-block-kubio-row__inner vertice-header__k__NJ1mZRrmEM-inner vertice-local-605-inner h-row align-items-lg-stretch align-items-md-stretch align-items-stretch justify-content-lg-center justify-content-md-center justify-content-center gutters-col-lg-0 gutters-col-v-lg-0 gutters-col-md-0 gutters-col-v-md-0 gutters-col-0 gutters-col-v-0">
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-header__k__jiOOrOoOCk-container vertice-local-606-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-header__k__jiOOrOoOCk-inner vertice-local-606-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align vertice-header__k__jiOOrOoOCk-align vertice-local-606-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php vertice_theme()->get('top-bar-list-icons')->render(); ?>
						</div>
					</div>
				</div>
				<div class="wp-block wp-block-kubio-column  position-relative wp-block-kubio-column__container vertice-header__k__BQ1nAM_xE1E-container vertice-local-614-container d-flex h-col-lg-auto h-col-md-auto h-col-auto" data-kubio="kubio/column">
					<div class="position-relative wp-block-kubio-column__inner vertice-header__k__BQ1nAM_xE1E-inner vertice-local-614-inner d-flex h-flex-basis h-px-lg-0 v-inner-lg-0 h-px-md-0 v-inner-md-0 h-px-0 v-inner-0">
						<div class="background-wrapper">
							<div class="background-layer background-layer-media-container-lg"></div>
							<div class="background-layer background-layer-media-container-md"></div>
							<div class="background-layer background-layer-media-container"></div>
						</div>
						<div class="position-relative wp-block-kubio-column__align vertice-header__k__BQ1nAM_xE1E-align vertice-local-614-align h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
							<?php vertice_theme()->get('top-bar-social-icons')->render(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

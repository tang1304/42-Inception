<li class="wp-block wp-block-kubio-iconlistitem  position-relative wp-block-kubio-iconlistitem__item vertice-header__k__snjyxIa_njN-item vertice-local-612-item" data-kubio="kubio/iconlistitem">
	<div class="position-relative wp-block-kubio-iconlistitem__text-wrapper vertice-header__k__snjyxIa_njN-text-wrapper vertice-local-612-text-wrapper">
		<span class="h-svg-icon wp-block-kubio-iconlistitem__icon vertice-header__k__snjyxIa_njN-icon vertice-local-612-icon" name="font-awesome/envelope">
			<?php $icon = \ColibriWP\Theme\View::getData('icon'); if (isset($icon['content'])) echo $icon['content'] ?>
		</span>
		<span class="position-relative wp-block-kubio-iconlistitem__text vertice-header__k__snjyxIa_njN-text vertice-local-612-text">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('text')); ?>
		</span>
	</div>
	<div class="last-el-spacer position-relative wp-block-kubio-iconlistitem__divider-wrapper vertice-header__k__snjyxIa_njN-divider-wrapper vertice-local-612-divider-wrapper"></div>
	<div class="position-relative wp-block-kubio-iconlistitem__divider-wrapper vertice-header__k__snjyxIa_njN-divider-wrapper vertice-local-612-divider-wrapper"></div>
</li>

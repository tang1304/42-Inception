<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<figure class="wp-block wp-block-kubio-image  position-relative wp-block-kubio-image__outer vertice-front-header__k__zB8ysbBLDm-outer vertice-local-139-outer size-large align-items-center" data-kubio="kubio/image">
	<div class="position-relative wp-block-kubio-image__captionContainer vertice-front-header__k__zB8ysbBLDm-captionContainer vertice-local-139-captionContainer">
		<div class="position-relative wp-block-kubio-image__frameContainer vertice-front-header__k__zB8ysbBLDm-frameContainer vertice-local-139-frameContainer">
			<?php $component->printImage(...array (
  0 => 'position-relative wp-block-kubio-image__image vertice-front-header__k__zB8ysbBLDm-image vertice-local-139-image d-flex',
  1 => NULL,
)); ?>
<?php $component->printFrame('position-relative wp-block-kubio-image__frameImage'); ?>
		</div>
	</div>
</figure>

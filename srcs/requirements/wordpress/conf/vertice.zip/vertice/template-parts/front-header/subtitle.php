<?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
<p class="wp-block wp-block-kubio-text  position-relative wp-block-kubio-text__text vertice-front-header__k__Xia0GT4t_-text vertice-local-131-text" data-kubio="kubio/text" id="paragraph-8">
	<?php $component->printSubtitle(); ?>
</p>

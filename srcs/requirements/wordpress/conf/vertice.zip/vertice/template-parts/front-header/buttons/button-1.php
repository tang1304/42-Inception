<span class="wp-block wp-block-kubio-button  position-relative wp-block-kubio-button__outer vertice-front-header__k__EWwtrkn9y-outer vertice-local-136-outer kubio-button-container" data-kubio="kubio/button">
	<a class="position-relative wp-block-kubio-button__link vertice-front-header__k__EWwtrkn9y-link vertice-local-136-link h-w-100 h-global-transition" href="<?php echo esc_url(\ColibriWP\Theme\View::getData('url')); ?>">
		<span class="position-relative wp-block-kubio-button__text vertice-front-header__k__EWwtrkn9y-text vertice-local-136-text kubio-inherit-typography">
			<?php echo esc_html(\ColibriWP\Theme\View::getData('label')); ?>
		</span>
	</a>
</span>

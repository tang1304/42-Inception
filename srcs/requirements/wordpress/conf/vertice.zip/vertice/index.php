<?php

get_header();

vertice_theme()->get( 'main' )->render();

get_footer();
